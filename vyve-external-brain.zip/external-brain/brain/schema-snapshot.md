# VYVE Health — Database Schema Snapshot

> Auto-generated from live Supabase project ixjfklpckgxrwjlfsaaz  
> Date: 10 April 2026  
> Tables: 36 | All RLS enabled

---

## members (8 rows) — PK: id, UNIQUE: email
Core member profiles. Email connects to all other tables via FK.

| Column | Type | Notes |
|--------|------|-------|
| id | uuid | PK, gen_random_uuid() |
| email | text | UNIQUE, FK target for 20+ tables |
| first_name, last_name | text | nullable |
| phone | text | nullable |
| created_at | timestamptz | default now() |
| persona | text | CHECK: NOVA/RIVER/SPARK/SAGE/HAVEN |
| persona_reason | text | nullable |
| persona_assigned_at | timestamptz | nullable |
| baseline_wellbeing/sleep/energy/stress/physical/diet/social/motivation | int | 1-10, nullable |
| training_location, equipment, injuries, exercises_to_avoid | text | nullable |
| experience_level | text | nullable |
| training_days_per_week | int | nullable |
| sleep_hours | numeric | nullable |
| sleep_bedtime, sleep_issues | text | nullable |
| sleep_wants_help | bool | nullable |
| activity_level | text | nullable |
| height_cm, weight_kg | numeric | nullable |
| tdee_maintenance, tdee_target, deficit_percentage | int | nullable |
| social_barriers | text | nullable |
| life_context | text[] | nullable |
| life_context_detail | text | nullable |
| alcohol_frequency | text | nullable |
| sensitive_context | bool | default false |
| past_barriers, success_vision, goal_style | text | nullable |
| reminder_frequency, tone_preference, overwhelm_response | text | nullable |
| has_smartphone, has_smartwatch | bool | nullable |
| specific_goal, additional_info, goal_focus | text | nullable |
| privacy_employer_reporting | bool | default true |
| notifications_milestones, notifications_weekly_summary | bool | default true |
| milestone_level | int | default 0 |
| milestone_message | text | nullable |
| milestone_read | bool | default true |
| cert_habits_count/workouts_count/cardio_count/checkins_count/sessions_count | int | default 0 |
| kahunas_qa_complete | bool | default false |
| stripe_customer_id | text | nullable |
| subscription_status | text | default 'active' |
| onboarding_complete | bool | default false |
| onboarding_completed_at | timestamptz | nullable |
| age | int | nullable |
| gender, gender_self_describe | text | nullable |
| company | text | nullable — display name |
| company_slug | text | nullable — URL slug |
| welcome_rec_1/2/3 | text | nullable — onboarding AI recommendations |
| welcome_persona_reason | text | nullable |
| contact_preference, support_areas, support_style, motivation_help | text | nullable |
| persona_switches | jsonb | nullable |
| re_engagement_stream | text | nullable |
| last_active_at | timestamptz | nullable |
| session_duration_preference | int | CHECK: 20/30/45/60 |
| pwa_installed | bool | default false |
| terms_accepted_at, privacy_accepted_at, health_data_consent_at | timestamptz | nullable |
| terms_version | text | nullable |
| health_data_consent | bool | default false |
| theme_preference | text | CHECK: light/dark/system |
| tdee_formula | text | nullable |

---

## daily_habits (42 rows) — FK: member_email → members.email, habit_id → habit_library.id
| Column | Type | Notes |
|--------|------|-------|
| id | uuid | PK |
| member_email | text | FK |
| activity_date | date | |
| day_of_week | text | |
| time_of_day | text | CHECK: morning/afternoon/evening/night |
| logged_at | timestamptz | default now() |
| notes | text | nullable |
| habit_id | uuid | FK → habit_library, nullable |
| habit_completed | bool | default true |

## workouts (54 rows) — FK: member_email → members.email
| Column | Type | Notes |
|--------|------|-------|
| id | uuid | PK |
| member_email | text | FK |
| activity_date | date | |
| day_of_week | text | |
| time_of_day | text | CHECK: morning/afternoon/evening/night |
| session_number | int | default 1, CHECK: 1 or 2 |
| plan_name, workout_name | text | nullable |
| duration_minutes | int | nullable |
| logged_at | timestamptz | default now() |

## cardio (19 rows) — FK: member_email → members.email
Same structure as workouts + cardio_type (text), distance_km (numeric).

## session_views (20 rows) — FK: member_email → members.email
| Column | Type | Notes |
|--------|------|-------|
| id, member_email, activity_date, day_of_week, time_of_day, session_number | — | Same as workouts |
| category | text | |
| session_name | text | nullable |
| youtube_url | text | nullable |
| minutes_watched | numeric | default 0 |

## replay_views (13 rows)
Same structure as session_views.

## wellbeing_checkins (11 rows) — FK: member_email → members.email
8 score columns (score_wellbeing/sleep/energy/stress/physical/diet/social/motivation) — int 1-10.  
composite_score (numeric), ai_recommendation (text), ai_persona (text), flow_type (active/quiet).  
engagement_score (int) — member engagement score at time of check-in.

## monthly_checkins (0 rows) — UNIQUE: (member_email, iso_month)
8 score columns (smallint 1-10) + 8 note columns (text).  
goal_progress_score (smallint 1-10), goal_progress_note (text).  
avg_score (numeric), ai_report (text).

## weekly_scores (11 rows) — UNIQUE: (member_email, iso_week, iso_year)
wellbeing_score (int 1-10), engagement_score (int 0-100).

## weekly_goals (5 rows) — UNIQUE: (member_email, week_start)
habits_target (3), workouts_target (2), cardio_target (1), sessions_target (1), checkin_target (1).

## workout_plans (244 rows) — exercise library
plan_name, plan_type (PPL/Upper_Lower/Full_Body/Home/Movement_Wellbeing), day_name, day_number, exercise_order, exercise_name, sets, reps, tempo, rest_seconds, notes, video_url, equipment_needed, muscle_group, difficulty, thumbnail_url.

## workout_plan_cache (3 rows) — UNIQUE: member_email
programme_json (jsonb), plan_duration_weeks, current_week, current_session.

## exercise_logs (94 rows)
member_email, exercise_name, activity_date, sets_completed, reps_completed, weight_kg, notes.

## exercise_swaps (3 rows)
member_email, original_exercise, replacement_exercise.

## exercise_notes (1 row)
member_email, exercise_name, note.

## custom_workouts (3 rows)
member_email, workout_name, exercises (jsonb, default []).

## personas (5 rows) — UNIQUE: name
name (NOVA/RIVER/SPARK/SAGE/HAVEN), display_name, tagline, description, suitable_for, never_assign_if, system_prompt, requires_professional_review.

## persona_switches (0 rows)
member_email, from_persona, to_persona, reason.

## running_plan_cache (3 rows) — UNIQUE: cache_key
goal, level, days_per_week, timeframe_weeks, long_run_day, plan_json (jsonb), use_count.

## knowledge_base (15 rows)
topic, subtopic, content, source, permit_general_advice, active.

## habit_themes (5 rows)
theme (sleep/movement/nutrition/mindfulness/social), display_name, description, active, month_label.

## habit_library (30 rows)
habit_pot (same CHECK as theme), habit_title, habit_description, habit_prompt, difficulty (easy/medium/hard).

## member_habits (4 rows)
member_email, habit_id (FK → habit_library), assigned_by (onboarding/ai/theme_update/self), active.

## nutrition_logs (3 rows)
member_email, activity_date, meal_type (breakfast/lunch/dinner/snacks), food_name, brand, barcode, off_id, calories_kcal, protein_g, carbs_g, fat_g, fibre_g, serving_size_g, serving_unit, servings.

## nutrition_my_foods (0 rows)
Same nutrition columns as nutrition_logs minus activity_date/meal_type/servings.

## nutrition_common_foods (125 rows)
food_name, category, brand, nutrition columns, search_terms, source.

## weight_logs (3 rows) — UPSERT: (member_email, logged_date)
member_email, logged_date, weight_kg.

## service_catalogue (21 rows)
type (live_session/replay/workout_plan/running_plan), category, name, description, youtube_url, riverside_url, duration_minutes, schedule_day/time, difficulty, active.

## certificates (0 rows)
member_email, activity_type (habits/workouts/cardio/checkins/sessions), milestone_count, charity_moment_triggered, certificate_url, global_cert_number.

## employer_members (0 rows)
member_email, employer_name, department, job_title, enrolled_at.

## engagement_emails (22 rows)
member_email, stream (A/B/C1/C2/C3), email_key, sent_at, brevo_message_id, open_count, click_count, suppressed.

## session_chat (3 rows)
session_type, member_email, display_name, message.

## ai_interactions (7 rows)
member_email, triggered_by (weekly_checkin/onboarding/running_plan/milestone/manual), persona, prompt_summary, recommendation, acted_on, decision_log (jsonb).

## activity_dedupe (494 rows)
source_table, member_email, activity_date, iso_week, iso_year, raw_payload (jsonb).

## qa_submissions (3 rows)
member_email, submitted_at.
