# How to Use the External Brain

> This guide is for Dean (CTO) — the human operator.

---

## Daily Workflow

### Starting a Session with Any AI

1. Open the AI tool (Claude, ChatGPT, Gemini, etc.).
2. Paste the contents of `prompts/cold-start.md` as your first message.
3. If the AI has file upload, attach `brain/master.md` instead.
4. State your task clearly: "I need to [fix X / build Y / audit Z]."

The AI will have full context and can begin immediately.

### Moving from Idea → Task → Execution

```
1. IDEA        → Write it in one sentence
2. TASK CARD   → Copy tasks/task-template.md, fill it in (2 minutes max)
3. PLAYBOOK    → Pick the right one (see below)
4. EXECUTE     → Paste task card + playbook reference into AI session
5. VERIFY      → Check the output against expected outcome in the task card
6. ARCHIVE     → Move completed task card to tasks/completed/
```

### When Ideas Arrive Mid-Session
Add them to `tasks/backlog.md` with a one-line description. Don't derail the current task.

---

## Choosing a Playbook

| Situation | Playbook | When |
|-----------|----------|------|
| Need to read or write files in the GitHub repo | `github-operator.md` | Every session that touches code |
| Full health check of the codebase | `repo-audit.md` | Monthly, or after major changes |
| Building a new page, feature, or Edge Function | `feature-build.md` | When adding new capability |
| Something is broken | `bug-fix.md` | When a user reports an issue or you spot one |

**Multiple playbooks can be combined.** For example, a feature build will also use the github-operator playbook for commits.

---

## Choosing an AI Model

| Task Type | Recommended Model | Why |
|-----------|-------------------|-----|
| Complex architecture, multi-file features, audits | Claude Opus / GPT-4o | Needs deep reasoning, large context |
| Single file edits, bug fixes, small features | Claude Sonnet / GPT-4o-mini | Fast, cheap, sufficient |
| Content generation, email drafts, copy | Any model | Not code-critical |
| Emergency recovery (lost access to primary) | Whatever is available | Cold-start prompt works with any model |

### When to Switch Models Mid-Task
- If the model starts hallucinating file names or table names → restart with `master.md` loaded
- If the model hits context limits → summarise progress, start new session with cold-start prompt + summary
- If the model can't use tools (e.g. no Composio/MCP access) → switch to a model that can, or use manual git workflow

---

## Updating the External Brain

### When to Update
- After any database schema change (new table, new column)
- After deploying a new Edge Function or bumping a version
- After a major feature ships
- After a business decision changes (pricing, tooling, etc.)

### How to Update
1. Edit the relevant file (`master.md`, `schema-snapshot.md`, etc.)
2. Update the "Last verified" date at the top
3. Commit to the external-brain repo (or wherever you store it)

### Quarterly Full Refresh
Every 3 months, run the `repo-audit.md` playbook and update all files with live data from Supabase.

---

## Emergency: Lost All AI Access

If you lose access to your primary AI account:

1. Sign up for any AI service (Claude, ChatGPT, Gemini, etc.)
2. Paste `prompts/cold-start.md` as your first message
3. You have full context. Resume work.

The External Brain is stored in your GitHub repo, Google Drive, or local machine — not inside any AI's memory.

---

## Task Backlog Management

Keep `tasks/backlog.md` as a simple prioritised list:

```markdown
## 🔴 Do Now
- [task one-liner]

## 🟡 This Week
- [task one-liner]

## 🟢 Later
- [task one-liner]
```

Move items up/down as priorities shift. When starting a task, create a full task card from the template.

---

## File Hygiene

- Keep `master.md` under 500 lines. If it grows, split sections into their own files.
- Keep `schema-snapshot.md` as a machine-readable reference — don't add prose.
- Archive completed task cards — don't delete them. They're useful for onboarding new AI sessions.
- Never put secrets in any External Brain file. Reference them by name only (e.g. "stored as ANTHROPIC_API_KEY in Supabase secrets").
