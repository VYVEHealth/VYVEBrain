# VYVE Health — Master Brain Document

> This document gives any AI everything it needs to understand and operate on the VYVE Health platform.  
> Last verified: 10 April 2026 against live Supabase project ixjfklpckgxrwjlfsaaz.

---

## 1. What Is VYVE Health?

VYVE Health CIC is a UK-based Community Interest Company building a proactive wellbeing platform for individuals and employers. The product covers three pillars — Physical, Mental, and Social health — and uses AI coaching personas to personalise the member experience.

**Stage:** Pre-revenue, MVP, validation.  
**Members:** 8 active (verified live). Inactive users were cleaned out. New members auto-created on onboarding.  
**Legal:** ICO registered (00013608608). CIC status gives 6–8 point advantage in public sector procurement.

### Team

| Role | Person | Email | Scope |
|------|--------|-------|-------|
| CEO / Founder | Lewis Vines | lewisvines@hotmail.com | Commercial, sales, content, AI ops skills |
| CTO / Co-Founder | Dean Brown | deanonbrown@hotmail.com | Technical, part-time until £6K/month revenue |

### Business Email
`team@vyvehealth.co.uk` — use for all business communications. Never use personal emails for business.

---

## 2. Product Overview

### What Members Get
- 5 AI coaching personas (NOVA, RIVER, SPARK, SAGE, HAVEN)
- 8-week personalised workout programmes
- Daily habit tracking with monthly themes
- Weekly and monthly wellbeing check-ins with AI reports
- AI-generated running plans
- Nutrition logging (TDEE, macros, food diary)
- Live sessions with real-time chat
- Certificate system with charity donation mechanic
- Leaderboards and engagement scoring

### Pricing
- **B2C:** £20/month individual
- **B2B:** £10/user/month (advertised at £20, discount applied). Volume tiers TBD for 200+ seats.
- **Stripe:** buy.stripe.com/00wfZicla1Em0NnaIB93y00. Coupons: VYVE15, VYVE10.

### Priority #1
Capacitor wrap for iOS App Store + Android Play Store. The PWA is ready. Blockers: health disclaimer (Lewis) + push notification permission.

---

## 3. Architecture

### Hosting
| Component | Where |
|-----------|-------|
| Member portal (PWA) | GitHub Pages → `online.vyvehealth.co.uk` — repo: `VYVEHealth/vyve-site` (PRIVATE) |
| Marketing site | GitHub Pages → `www.vyvehealth.co.uk` — repo: `VYVEHealth/Test-Site-Finalv3` |
| Backend / DB | Supabase Pro (West EU/Ireland) — project `ixjfklpckgxrwjlfsaaz` |
| AI | Anthropic API (Claude Sonnet 4 + Haiku 4.5) — server-side in Edge Functions ONLY |
| Email | Brevo (free tier, 300/day) |
| Payments | Stripe |
| Analytics | PostHog (EU endpoint, identity wired to Supabase Auth) |
| CRM | HubSpot (Hub ID: 148106724) |
| Automation | Make (Lewis only — social media) |

### Authentication
**Supabase Auth** with auth.js v2.2. All portal pages gated. Auth0 is FULLY RETIRED — never reference it.

### Repo Structure (vyve-site)
The portal repo contains single-file HTML pages. Each page is self-contained with inline CSS/JS. There is no build process, no bundler, no module system. Files are committed directly via the `github-proxy` Edge Function.

Key files:
- `index.html` — member dashboard
- `habits.html`, `workouts.html`, `nutrition.html`, `log-food.html` — tracking pages
- `wellbeing-checkin.html` — weekly check-in
- `monthly-checkin.html` — monthly 8-pillar check-in with AI report
- `sessions.html` — live session listings with chat
- `running-plan.html` — AI running plan generator
- `settings.html`, `certificates.html`, `engagement.html`, `leaderboard.html`
- `login.html`, `set-password.html`
- `strategy.html` — internal dashboard (password: vyve2026)
- `sw.js` — service worker (cache version must be bumped after every push)
- `auth.js` — Supabase Auth wrapper (v2.2)
- `theme.js` — dark/light mode
- `nav.js` — navigation

### Edge Functions (24 live, 6 stubs pending deletion)
| Function | Version | Purpose |
|----------|---------|---------|
| onboarding | v43 | Two-phase: fast return + background 8-week programme generation |
| member-dashboard | v25 | Full dashboard data, JWT-preferred auth |
| wellbeing-checkin | v22 | Weekly check-in + AI recommendations |
| monthly-checkin | v5 | Monthly 8-pillar check-in, Haiku model, AI report |
| log-activity | v8 | PWA activity logging |
| employer-dashboard | v20 | Aggregate data, API key auth, no PII |
| anthropic-proxy | v5 | AI proxy for running plans |
| send-email | v11 | Brevo transactional |
| re-engagement-scheduler | v11 | Cron 8:00 UTC, streams A/B/C1/C2/C3 |
| daily-report | v11 | Cron 8:05 UTC |
| weekly-report | v7 | Weekly summary |
| monthly-report | v7 | Monthly summary |
| certificate-checker | v10 | Cron 9:00 UTC, HTML certs, global sequential numbers |
| certificate-serve | v8 | Serves certificate HTML |
| github-proxy | v11 | GET + PUT to vyve-site via GITHUB_PAT |
| github-proxy-marketing | v2 | Marketing site proxy |
| off-proxy | v9 | Open Food Facts API proxy |
| send-session-recap | v4 | Session recap emails |
| send-journey-recap | v4 | Journey recap emails |
| ops-brief | v2 | Ops brief generation |
| storage-cleanup | v2 | Storage cleanup |
| re-engagement-test-sender | v8 | Test emails |
| send-test-welcome | v2 | Test welcome emails |

---

## 4. Database (Supabase — 36 Tables)

All tables have RLS enabled. Email is the primary key connecting members across all tables. Full schema with columns is in `brain/schema-snapshot.md`.

### Core Activity Tables
members (8 rows), daily_habits (42), workouts (54), cardio (19), session_views (20), replay_views (13), kahunas_checkins (14), weekly_scores (11), wellbeing_checkins (11), monthly_checkins (0), ai_interactions (7), activity_dedupe (494), session_chat (3)

### Workout & Exercise Tables
workout_plans (244), workout_plan_cache (3), exercise_logs (94), exercise_swaps (3), exercise_notes (1), custom_workouts (3)

### AI & Persona Tables
personas (5), persona_switches (0), running_plan_cache (3), weekly_goals (5), knowledge_base (15)

### Habit & Nutrition Tables
habit_themes (5), habit_library (30), member_habits (4), nutrition_logs (3), nutrition_my_foods (0), nutrition_common_foods (125), weight_logs (3)

### Other Tables
service_catalogue (21), certificates (0), employer_members (0), engagement_emails (22), qa_submissions (3)

### SQL Functions (15)
set_activity_time_fields, get_charity_total, get_capped_activity_count, next_certificate_number, set_checkin_iso_week, cap_cardio, cap_daily_habits, cap_kahunas_checkins, cap_session_views, cap_workouts, increment_cardio_counter, increment_checkin_counter, increment_habit_counter, increment_session_counter, increment_workout_counter

### Activity Caps (BEFORE INSERT Triggers)
| Activity | Cap |
|----------|-----|
| daily_habits | 1 per day |
| workouts | 2 per day |
| cardio | 2 per day |
| session_views | 2 per day |
| kahunas_checkins | 1 per ISO week |

Over-cap inserts routed to `activity_dedupe` — not discarded.

---

## 5. AI Personas

| Persona | Character |
|---------|-----------|
| NOVA | High-performance coach. Data-led, metrics-focused. |
| RIVER | Mindful guide. Calm, empathetic, holistic. |
| SPARK | Motivational powerhouse. Energetic, challenge-driven. |
| SAGE | Knowledge-first mentor. Evidence-based. |
| HAVEN | Mental health companion. Trauma-informed. NOT LIVE — needs professional review. |

**Critical rule:** NEVER assign NOVA or SPARK if serious life context flagged in onboarding Section G.

---

## 6. Hard Rules (NEVER BREAK)

1. **Anthropic API keys NEVER in HTML or GitHub.** Server-side Edge Functions only. Stored as `ANTHROPIC_API_KEY` in Supabase secrets.
2. **Auth0 is dead.** Never reference it. Supabase Auth is the only auth system.
3. **Kahunas / PAD are dead.** Never reference them in member-facing copy. Product is "VYVE Health app".
4. **Never say "Corporate Wellness"** as a tagline.
5. **sw.js cache must be bumped** after every portal push. Pattern: `vyve-cache-v2026-04-0[letter]`.
6. **Edge Function deploys require full index.ts.** No partial updates.
7. **Theme system uses dual dark/light CSS blocks.** Never single `:root`. Include `theme.js` before closing `</head>`.
8. **All portal writes go through Edge Functions or direct Supabase client with JWT.** Never use anon key for writes.
9. **Employer dashboard shows aggregate data only.** No PII. No individual names.
10. **HAVEN must signpost professional help** if member in crisis. Do not activate in production without qualified review.
11. **GitHub writes use github-proxy EF** (PUT method). The GitHub MCP is READ-ONLY and always returns 403 on writes.
12. **workouts.html uses MutationObserver** on `#app` div for auth. Do NOT revert to waitForAuth polling.
13. **Business email is team@vyvehealth.co.uk.** Never use personal emails for business.
14. **Google Sheets retired** for portal data. Only used for business docs.
15. **Dean does not use Make.** Make is Lewis-only for social media.

---

## 7. Onboarding Flow

```
Stripe payment → onboarding_v8.html (10 sections) → onboarding EF v43
  Phase 1 (fast): persona + habits + programme overview + DB writes + Brevo welcome email
  Phase 2 (background via waitUntil): full 8-week workout JSON → workout_plan_cache
→ Supabase Auth user created → member logs in
```

---

## 8. Key URLs & Credentials

| Reference | Value |
|-----------|-------|
| Supabase Project | ixjfklpckgxrwjlfsaaz |
| PostHog Key | phc_8gekeZglc1HBDu3d9kMuqOuRWn6HIChhnaiQi6uvonl |
| HubSpot Hub ID | 148106724 |
| Sage Deal (HubSpot) | 495586118853 |
| Strategy Dashboard | online.vyvehealth.co.uk/strategy.html (password: vyve2026) |
| Demo Reset | online.vyvehealth.co.uk/index.html?reset=checkin |
| github-proxy PUT | `https://ixjfklpckgxrwjlfsaaz.supabase.co/functions/v1/github-proxy?path=filename.html` |

---

## 9. What NOT to Do

- Do NOT create tables that already exist (check schema-snapshot.md first)
- Do NOT reference Auth0, Kahunas, PAD, or Google Sheets for portal data
- Do NOT put API keys in HTML files
- Do NOT use `WidthType.PERCENTAGE` in docx generation (breaks in Google Docs)
- Do NOT suggest Make automations for Dean
- Do NOT modify Edge Functions without providing complete index.ts
- Do NOT forget to bump sw.js after portal changes
- Do NOT create monthly_summaries, activity_patterns, charity_totals, audit_log, or milestone_messages tables — they were planned but never built and are not needed
