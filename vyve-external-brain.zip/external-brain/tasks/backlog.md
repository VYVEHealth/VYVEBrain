# VYVE Health — Task Backlog

> Prioritised list of outstanding work. Updated 10 April 2026.

---

## 🔴 Do Now

- Delete 6 stub Edge Functions (check-employer-key, backfill-auth-users, github-write-once, monthly-checkin-test, run-migration-monthly-checkins, run-monthly-checkins-migration)
- Push notification permission request (Capacitor blocker)
- Health disclaimer — Lewis sign-off needed (Capacitor blocker)
- Add monthly-checkin link to portal nav / dashboard
- Weekly check-in slider questions — Lewis to confirm wording

## 🟡 This Week

- Brevo logo removal (~$12/month) — Lewis action before enterprise demo
- Facebook Make connection refresh — EXPIRES 22 MAY 2026 (Lewis)
- Re-engagement automations x3 — blocked on Lewis email copy
- Live viewer count on session pages (show when 20+ viewers)
- AI weekly goals system — blocked on Lewis copy approval
- B2B volume discount tiers — formally define before first enterprise contract
- Fix Make social publisher (Scenario 4950386) — 133 posts stuck since 23 March (Lewis)
- Consolidate duplicate RLS policies on cardio, daily_habits, workouts, members, replay_views, session_views, weekly_scores, wellbeing_checkins

## 🟢 Later

- Capacitor wrap for iOS + Android (after blockers resolved)
- Modularise workouts.html (post-Capacitor)
- Build process / bundler (post-Capacitor)
- ARIA labels for accessibility (post-enterprise contract)
- Edge Function wrappers for client-side writes
- Sentry error tracking
- PostHog custom events
- TypeScript migration
- Move pg_net extension from public to extensions schema
- Drop duplicate indexes on exercise_notes and weekly_scores
- Today's Progress dot strip (Lewis copy approval needed)
- Weekly progress summary email — Friday, AI-generated, Brevo (Lewis copy needed)
- Persona context modifier system
- HAVEN professional review before go-live
- Google Workspace migration (post first enterprise contract)
- External DPO service (before 500 members)
- National Lottery Awards for All application
- The Fore grant — register June/July 2026
- WHISPA research partnership — monitor May 2026 launch
