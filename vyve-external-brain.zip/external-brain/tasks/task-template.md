# Task Card

> Copy this template for each new task. Fill in all sections. Paste into an AI session with the cold-start prompt.

---

## Task ID
`VYVE-[number]`

## Title
[One-line description]

## Type
- [ ] Feature Build
- [ ] Bug Fix
- [ ] Repo Audit
- [ ] Database Change
- [ ] Edge Function Update
- [ ] Documentation Update
- [ ] Other

## Priority
- [ ] 🔴 Critical (blocking users or revenue)
- [ ] 🟡 High (should do this week)
- [ ] 🟢 Normal (backlog)

## Context
[What prompted this task? What's the background?]

## Requirements
[What exactly needs to happen? Be specific.]

1. [Step or requirement 1]
2. [Step or requirement 2]
3. [Step or requirement 3]

## Files Affected
| File | Action |
|------|--------|
| [filename] | [create / modify / delete] |
| sw.js | bump cache version |

## Database Changes
| Table | Action | Details |
|-------|--------|---------|
| [table name] | [create / alter / query] | [description] |

## Edge Functions
| Function | Action | Details |
|----------|--------|---------|
| [function name] | [create / update / delete] | [description] |

## Expected Outcome
[What does "done" look like? How do you verify it worked?]

## Playbook Reference
[Which playbook(s) to follow — e.g. `playbooks/feature-build.md` + `playbooks/github-operator.md`]

## Blockers
[Anything that must happen before this task can start — e.g. "Lewis sign-off on copy"]

## Notes
[Anything else the AI needs to know]

---

## Completion Log
**Started:** [date]  
**Completed:** [date]  
**AI Model Used:** [e.g. Claude Opus, GPT-4o]  
**Summary of Changes:**  
[Brief description of what was actually done]
